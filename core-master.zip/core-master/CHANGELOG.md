# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/).

This is a template changelog file.
See here for the [V10 changelog](https://github.com/owncloud/core/blob/stable10/CHANGELOG.md).

## [Unreleased]
### Added

### Changed

### Removed

### Fixed

[Unreleased]: https://github.com/owncloud/core/compare/stable10...master
