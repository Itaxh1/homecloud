OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Aniversari dels contactes",
    "Personal" : "Personal",
    "Contacts" : "Contactes",
    "Technical details" : "Detalls tècnics",
    "Remote Address: %s" : "Adreça remota: %s",
    "Request ID: %s" : "Sol·licitud ID: %s "
},
"nplurals=2; plural=(n != 1);");
