OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "ຕິດຕໍ່ວັນເກີດ",
    "Personal" : "ສ່ວນບຸກຄົນ",
    "Contacts" : "ຕິດຕໍ່ພົວພັນ",
    "Technical details" : "ລາຍລະອຽດເຕັກນິກ",
    "Remote Address: %s" : "ທີ່ຢູ່ໄລຍະໄກ: %s",
    "Request ID: %s" : "ການຮ້ອງຂໍໄອດີ: %s"
},
"nplurals=1; plural=0;");
