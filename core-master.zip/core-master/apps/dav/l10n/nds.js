OC.L10N.register(
    "dav",
    {
    "Personal" : "Persönlich"
},
"nplurals=2; plural=(n != 1);");
