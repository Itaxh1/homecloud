OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Gebuertsdeeg vun de Kontakter",
    "Personal" : "Perséinlech",
    "Contacts" : "Kontakter",
    "Technical details" : "Technesch Detailer",
    "Remote Address: %s" : "D'Adress op Distanz: %s",
    "Request ID: %s" : "ID ufroen: %s"
},
"nplurals=2; plural=(n != 1);");
