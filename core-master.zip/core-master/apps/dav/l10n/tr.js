OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Kişi doğum günleri",
    "Personal" : "Kişisel",
    "Contacts" : "Kişiler",
    "Technical details" : "Teknik ayrıntılar",
    "Remote Address: %s" : "Uzak Adres: %s",
    "Request ID: %s" : "İstek Kimliği: %s"
},
"nplurals=2; plural=(n > 1);");
