OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Compleanni dei contatti",
    "Personal" : "Personale",
    "Contacts" : "Contatti",
    "Technical details" : "Dettagli tecnici",
    "Remote Address: %s" : "Indirizzo remoto: %s",
    "Request ID: %s" : "ID richiesta: %s"
},
"nplurals=2; plural=(n != 1);");
