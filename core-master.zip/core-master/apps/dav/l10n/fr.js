OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Anniversaires des contacts",
    "Personal" : "Personnel",
    "Contacts" : "Contacts",
    "Technical details" : "Renseignements techniques",
    "Remote Address: %s" : "Adresse distante : %s",
    "Request ID: %s" : "ID de la demande : %s"
},
"nplurals=2; plural=(n > 1);");
