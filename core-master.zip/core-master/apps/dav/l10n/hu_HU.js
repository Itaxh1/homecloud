OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Az ismerősök születésnapjai",
    "Personal" : "Személyes",
    "Contacts" : "Névjegyek",
    "Technical details" : "Technikai adatok",
    "Remote Address: %s" : "Távoli cím: %s",
    "Request ID: %s" : "Kérelem azonosító: %s"
},
"nplurals=2; plural=(n != 1);");
