OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Cumpleaños de los contactos",
    "Personal" : "Personal",
    "Contacts" : "Contactos",
    "Technical details" : "Detalles técnicos",
    "Remote Address: %s" : "Dirección remota: %s",
    "Request ID: %s" : "ID de la solicitud: %s"
},
"nplurals=2; plural=(n != 1);");
