OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "تاریخ تولد افراد",
    "Personal" : "شخصی",
    "Contacts" : "ارتباط‌ها",
    "Technical details" : "جزئیات فنی",
    "Remote Address: %s" : "آدرس راه‌دور: %s",
    "Request ID: %s" : "ID درخواست: %s"
},
"nplurals=2; plural=(n > 1);");
