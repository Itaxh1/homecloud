OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Родендени на контактите",
    "Personal" : "Лично",
    "Contacts" : "Контакти",
    "Technical details" : "Технички детали",
    "Remote Address: %s" : "Далечинска адреса: %s",
    "Request ID: %s" : "Барање ID: %s"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
