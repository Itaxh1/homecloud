OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Urodziny",
    "Personal" : "Osobiste",
    "Contacts" : "Kontakty",
    "Technical details" : "Szczegóły techniczne",
    "Remote Address: %s" : "Adres zdalny: %s",
    "Request ID: %s" : "ID żądania: %s"
},
"nplurals=4; plural=(n==1 ? 0 : (n%10>=2 && n%10<=4) && (n%100<12 || n%100>14) ? 1 : n!=1 && (n%10>=0 && n%10<=1) || (n%10>=5 && n%10<=9) || (n%100>=12 && n%100<=14) ? 2 : 3);");
