OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Kontaktu jubilejas",
    "Personal" : "Personīgi",
    "Contacts" : "Kontakti"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
