OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Geburtstage Deiner Kontakte",
    "Personal" : "Persönlich",
    "Contacts" : "Kontakte",
    "Technical details" : "Technische Details",
    "Remote Address: %s" : "Entfernte Adresse: %s",
    "Request ID: %s" : "Anforderungskennung: %s"
},
"nplurals=2; plural=(n != 1);");
