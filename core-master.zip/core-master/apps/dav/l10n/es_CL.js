OC.L10N.register(
    "dav",
    {
    "Personal" : "Personal"
},
"nplurals=2; plural=(n != 1);");
