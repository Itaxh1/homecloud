OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Ծննդյան օրեր",
    "Personal" : "Անձնական",
    "Contacts" : "Կոնտակտներ",
    "Technical details" : "Տեխնիկական մանրամասներ",
    "Remote Address: %s" : "Հեռակա հասցե. %s"
},
"nplurals=2; plural=(n != 1);");
