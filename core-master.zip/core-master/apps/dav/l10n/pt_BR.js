OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Contato de aniversários ",
    "Personal" : "Pessoal",
    "Contacts" : "Contatos",
    "Technical details" : "Detalhes técnicos",
    "Remote Address: %s" : "Endereço Remoto: %s",
    "Request ID: %s" : "ID do Pedido: %s"
},
"nplurals=2; plural=(n > 1);");
