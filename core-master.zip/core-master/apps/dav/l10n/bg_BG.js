OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Рождени дни на контакти",
    "Personal" : "Лично",
    "Contacts" : "Контакти",
    "Technical details" : "Технически подробности",
    "Remote Address: %s" : "Отдалечен адрес: %s",
    "Request ID: %s" : "ID на заявка: %s"
},
"nplurals=2; plural=(n != 1);");
