OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "聯絡人生日",
    "Personal" : "個人",
    "Contacts" : "通訊錄",
    "Technical details" : "技術細節",
    "Remote Address: %s" : "遠端位置：%s",
    "Request ID: %s" : "請求編號：%s"
},
"nplurals=1; plural=0;");
