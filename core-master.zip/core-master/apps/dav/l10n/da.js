OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Kontakters fødselsdage",
    "Personal" : "Personligt",
    "Contacts" : "Kontakter",
    "Technical details" : "Tekniske detaljer",
    "Remote Address: %s" : "Fjernadresse: %s",
    "Request ID: %s" : "Forespørgsels-ID: %s"
},
"nplurals=2; plural=(n != 1);");
