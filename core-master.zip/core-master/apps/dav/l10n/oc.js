OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Anniversaris dels contactes",
    "Personal" : "Personal",
    "Contacts" : "Contactes",
    "Technical details" : "Enstresenhas tecnicas",
    "Remote Address: %s" : "Adreça distanta : %s",
    "Request ID: %s" : "ID de la demanda : %s"
},
"nplurals=2; plural=(n > 1);");
