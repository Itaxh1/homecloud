OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Verjaardagen contactpersonen",
    "Personal" : "Persoonlijk",
    "Contacts" : "Contactpersonen",
    "Technical details" : "Technische details",
    "Remote Address: %s" : "Extern adres: %s",
    "Request ID: %s" : "Aanvraag ID: %s"
},
"nplurals=2; plural=(n != 1);");
