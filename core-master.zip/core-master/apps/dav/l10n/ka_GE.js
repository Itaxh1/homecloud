OC.L10N.register(
    "dav",
    {
    "Personal" : "პირადი",
    "Contacts" : "კონტაქტები"
},
"nplurals=2; plural=(n!=1);");
