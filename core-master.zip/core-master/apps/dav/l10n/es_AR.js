OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Cumpleaños",
    "Personal" : "Personal",
    "Contacts" : "Contactos",
    "Technical details" : "Detalles técnicos",
    "Remote Address: %s" : "Dirección Remota: %s",
    "Request ID: %s" : "ID requiriente: %s"
},
"nplurals=2; plural=(n != 1);");
