OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "連絡先の誕生日",
    "Personal" : "個人",
    "Contacts" : "アドレス帳",
    "Technical details" : "技術詳細",
    "Remote Address: %s" : "リモートアドレス: %s",
    "Request ID: %s" : "リクエスト ID: %s"
},
"nplurals=1; plural=0;");
