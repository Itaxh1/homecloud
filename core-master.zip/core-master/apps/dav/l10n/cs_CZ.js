OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Narozeniny kontaktů",
    "Personal" : "Osobní",
    "Contacts" : "Kontakty",
    "Technical details" : "Technické detaily",
    "Remote Address: %s" : "Vzdálená adresa: %s",
    "Request ID: %s" : "ID požadavku: %s"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n >= 2 && n <= 4 && n % 1 == 0) ? 1: (n % 1 != 0 ) ? 2 : 3;");
