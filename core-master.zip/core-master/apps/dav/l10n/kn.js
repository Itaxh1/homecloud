OC.L10N.register(
    "dav",
    {
    "Personal" : "﻿ವೈಯಕ್ತಿಕ",
    "Technical details" : "ತಾಂತ್ರಿಕ ವಿವರಗಳು",
    "Remote Address: %s" : "ಆಚೆ-ಗಣಕದ ವಿಳಾಸ : %s",
    "Request ID: %s" : "ವಿನಂತಿಯ ಸಂಖ್ಯೆ: %s"
},
"nplurals=2; plural=(n > 1);");
