OC.L10N.register(
    "dav",
    {
    "Personal" : "यक्तिगत"
},
"nplurals=2; plural=(n != 1);");
