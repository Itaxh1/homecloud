OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Kontak hari ultah",
    "Personal" : "Pribadi",
    "Contacts" : "Kontak",
    "Technical details" : "Rincian teknis",
    "Remote Address: %s" : "Alamat remote: %s",
    "Request ID: %s" : "ID Permintaan: %s"
},
"nplurals=1; plural=0;");
