OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Kontakters bursdager",
    "Personal" : "Personlig",
    "Contacts" : "Kontakter",
    "Technical details" : "Tekniske detaljer",
    "Remote Address: %s" : "Ekstern adresse: %s",
    "Request ID: %s" : "Forespørsels-ID: %s"
},
"nplurals=2; plural=(n != 1);");
