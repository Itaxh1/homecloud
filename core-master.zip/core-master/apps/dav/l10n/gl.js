OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Aniversarios dos contactos",
    "Personal" : "Persoal",
    "Contacts" : "Contactos",
    "Technical details" : "Detalles técnicos",
    "Remote Address: %s" : "Enderezo remoto: %s",
    "Request ID: %s" : "ID da petición: %s"
},
"nplurals=2; plural=(n != 1);");
