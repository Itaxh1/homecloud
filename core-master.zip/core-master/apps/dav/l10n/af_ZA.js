OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Kontak verjaardae",
    "Personal" : "Persoonlik",
    "Contacts" : "Kontakte",
    "Technical details" : "Tegniese details",
    "Remote Address: %s" : "Afstandsadres: %s",
    "Request ID: %s" : "Versoek-ID: %s"
},
"nplurals=2; plural=(n != 1);");
