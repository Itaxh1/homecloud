OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Cumpleaños de los contactos",
    "Personal" : "Personal",
    "Contacts" : "Contactos",
    "Technical details" : "Detalles técnnicos",
    "Remote Address: %s" : "Dirección Remota: %s",
    "Request ID: %s" : "ID de Solicitud: %s"
},
"nplurals=2; plural=(n != 1);");
