OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Datëlindje kontaktesh",
    "Personal" : "Personale",
    "Contacts" : "Kontakte",
    "Technical details" : "Hollësi teknike",
    "Remote Address: %s" : "Adresë e Largët: %s",
    "Request ID: %s" : "ID Kërkese: %s"
},
"nplurals=2; plural=(n != 1);");
