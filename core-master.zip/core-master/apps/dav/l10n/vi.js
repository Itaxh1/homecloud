OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Danh sách sinh nhật",
    "Personal" : "Cá nhân",
    "Contacts" : "Danh bạ"
},
"nplurals=1; plural=0;");
