OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "联系人生日",
    "Personal" : "个人",
    "Contacts" : "联系人",
    "Technical details" : "技术细节",
    "Remote Address: %s" : "远程地址： %s",
    "Request ID: %s" : "请求 ID: %s"
},
"nplurals=1; plural=0;");
