OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Cumpleaños de los contautos",
    "Personal" : "Personal",
    "Contacts" : "Contautos",
    "Technical details" : "Detalles teúnicos",
    "Remote Address: %s" : "Accesu Remotu: %s",
    "Request ID: %s" : "Solicitú d'ID: %s"
},
"nplurals=2; plural=(n != 1);");
