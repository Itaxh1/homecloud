OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "연락처에 등록된 생일",
    "Personal" : "개인",
    "Contacts" : "연락처",
    "Technical details" : "기술 정보",
    "Remote Address: %s" : "원격 주소: %s",
    "Request ID: %s" : "요청 ID: %s"
},
"nplurals=1; plural=0;");
