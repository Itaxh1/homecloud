OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Kontakters födelsedagar",
    "Personal" : "Personligt",
    "Contacts" : "Kontakter",
    "Technical details" : "Tekniska detaljer",
    "Remote Address: %s" : "Fjärradress: %s",
    "Request ID: %s" : "Begärd ID: %s"
},
"nplurals=2; plural=(n != 1);");
