OC.L10N.register(
    "dav",
    {
    "Personal" : "వ్యక్తిగతం"
},
"nplurals=2; plural=(n != 1);");
