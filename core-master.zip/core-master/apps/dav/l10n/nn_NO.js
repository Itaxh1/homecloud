OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Kontaktbursdagar",
    "Personal" : "Personleg",
    "Contacts" : "Kontaktar",
    "Technical details" : "Tekniske detaljer",
    "Remote Address: %s" : "Ekstern adresse %s",
    "Request ID: %s" : "Førespurnad ID %s"
},
"nplurals=2; plural=(n != 1);");
