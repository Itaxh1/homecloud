OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "יום הולדת של אנשי קשר",
    "Personal" : "אישי",
    "Contacts" : "אנשי קשר",
    "Technical details" : "פרטים טכנים",
    "Remote Address: %s" : "כתובת מרוחקת: %s",
    "Request ID: %s" : "מספר זיהוי מבוקש: %s"
},
"nplurals=4; plural=(n == 1 && n % 1 == 0) ? 0 : (n == 2 && n % 1 == 0) ? 1: (n % 10 == 0 && n % 1 == 0 && n > 10) ? 2 : 3;");
