OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Naskiĝotagoj de la kontaktoj",
    "Personal" : "Persona",
    "Contacts" : "Kontaktoj",
    "Technical details" : "Teĥnikaj detaloj",
    "Remote Address: %s" : "Fora adreso: %s",
    "Request ID: %s" : "Peta identigilo: %s"
},
"nplurals=2; plural=(n != 1);");
