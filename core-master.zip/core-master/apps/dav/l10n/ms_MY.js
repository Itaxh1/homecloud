OC.L10N.register(
    "dav",
    {
    "Personal" : "Peribadi",
    "Contacts" : "Hubungi "
},
"nplurals=1; plural=0;");
