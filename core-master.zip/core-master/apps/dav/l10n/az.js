OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Əlaqə ad günləri",
    "Personal" : "Şəxsi",
    "Contacts" : "Əlaqələr"
},
"nplurals=2; plural=(n != 1);");
