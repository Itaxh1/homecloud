OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "วันเกิดของผู้ติดต่อ",
    "Personal" : "ส่วนตัว",
    "Contacts" : "ข้อมูลผู้ติดต่อ",
    "Technical details" : "รายละเอียดทางเทคนิค",
    "Remote Address: %s" : "ที่อยู่รีโมท: %s",
    "Request ID: %s" : "คำขอ ID: %s"
},
"nplurals=1; plural=0;");
