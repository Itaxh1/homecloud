OC.L10N.register(
    "dav",
    {
    "Personal" : "شخصی"
},
"nplurals=2; plural=(n != 1);");
