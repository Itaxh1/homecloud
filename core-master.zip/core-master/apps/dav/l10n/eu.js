OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "kontaktuen urtebetetze datak",
    "Personal" : "Pertsonala",
    "Contacts" : "Kontaktuak",
    "Technical details" : "Arazo teknikoak",
    "Remote Address: %s" : "Urruneko Helbidea: %s",
    "Request ID: %s" : "Eskariaren IDa: %s"
},
"nplurals=2; plural=(n != 1);");
