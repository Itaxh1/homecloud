OC.L10N.register(
    "dav",
    {
    "Contact birthdays" : "Aniversários do contacto",
    "Personal" : "Pessoal",
    "Contacts" : "Contactos",
    "Technical details" : "Detalhes técnicos",
    "Remote Address: %s" : "Endereço remoto: %s",
    "Request ID: %s" : "Id. do pedido: %s"
},
"nplurals=2; plural=(n != 1);");
