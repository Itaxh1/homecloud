OC.L10N.register(
    "comments",
    {
    "Cancel" : "﻿ರದ್ದು",
    "Save" : "﻿ಉಳಿಸಿ"
},
"nplurals=2; plural=(n > 1);");
