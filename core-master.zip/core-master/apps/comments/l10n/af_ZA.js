OC.L10N.register(
    "comments",
    {
    "Type in a new comment..." : "Tik ’n nuwe kommentaar in…",
    "Delete comment" : "Skrap kommentaar",
    "Post" : "Plaas",
    "Cancel" : "Kanselleer",
    "Edit comment" : "Wysig kommentaar",
    "[Deleted user]" : "[Geskrapte gebruiker]",
    "Comments" : "Kommentare",
    "No other comments available" : "Geen ander kommentare beskikbaar",
    "More comments..." : "Nog kommentare…",
    "Save" : "Bewaar",
    "Allowed characters {count} of {max}" : "Toegelate karakters {count} van {max}",
    "{count} unread comments" : "{count} ongeleesde kommentare",
    "Comment" : "Kommentaar",
    "<strong>Comments</strong> for files <em>(always listed in stream)</em>" : "<strong>Kommentare</strong> vir lêers <em>(word altyd in die stroom gelys)</em>",
    "You commented" : "U het kommentaar gelewer",
    "%1$s commented" : "%1$s het kommentaar gelewer",
    "You commented on %2$s" : "U het kommentaar op %2$s gelewer",
    "%1$s commented on %2$s" : "%1$s het kommentaar op %2$s gelewer"
},
"nplurals=2; plural=(n != 1);");
