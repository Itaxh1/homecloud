OC.L10N.register(
    "comments",
    {
    "Cancel" : "Hủy",
    "Save" : "Lưu"
},
"nplurals=1; plural=0;");
