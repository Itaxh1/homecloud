OC.L10N.register(
    "comments",
    {
    "Type in a new comment..." : "Укуцајте нови коментар...",
    "Delete comment" : "Обриши коментар",
    "Post" : "Објави",
    "Cancel" : "Откажи",
    "Edit comment" : "Уреди коментар",
    "[Deleted user]" : "[Обрисан корисник]",
    "Comments" : "Коментари",
    "No other comments available" : "Нема других коментара",
    "More comments..." : "Још коментара...",
    "Save" : "Сачувај",
    "Allowed characters {count} of {max}" : "Дозвољених {count} знакова од {max}",
    "{count} unread comments" : "{count} непрочитаних коментара",
    "Comment" : "Коментар",
    "%1$s commented" : "%1$s коментариса",
    "%1$s commented on %2$s" : "%1$s коментариса на %2$s"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);");
