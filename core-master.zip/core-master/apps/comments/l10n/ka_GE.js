OC.L10N.register(
    "comments",
    {
    "Cancel" : "უარყოფა",
    "Save" : "შენახვა"
},
"nplurals=2; plural=(n!=1);");
