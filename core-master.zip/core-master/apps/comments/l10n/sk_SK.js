OC.L10N.register(
    "comments",
    {
    "Cancel" : "Zrušiť",
    "Save" : "Uložiť",
    "Comment" : "Komentár"
},
"nplurals=4; plural=(n % 1 == 0 && n == 1 ? 0 : n % 1 == 0 && n >= 2 && n <= 4 ? 1 : n % 1 != 0 ? 2: 3);");
