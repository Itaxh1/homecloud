OC.L10N.register(
    "comments",
    {
    "Cancel" : "Цуцлах",
    "Save" : "Хадгалах"
},
"nplurals=2; plural=(n != 1);");
